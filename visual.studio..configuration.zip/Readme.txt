1. Download EmacsEmulation.vsix

2. rename '.vsix' to '.zip' and unzip

3. open 'catalog.json', 'manifest.json', 'extension.vsixmanifest'

4. edit '...CoreEditor":"[15.0,16.0)"}' -> 'CoreEditor":"[15.0,)"}'

5. zip files and rename '.zip' to '.vsix'

6. try it!